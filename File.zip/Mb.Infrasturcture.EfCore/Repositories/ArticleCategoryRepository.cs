﻿using MasterBlog.Domain.ArticleCategoryAgg;
using MB.Domain.ArticleCategoryAgg;

namespace MB.Infrasturcture.EfCore.Repositories
{
    public class ArticleCategoryRepository:IArticleCategoryRepository
    {
        private readonly MasterBloggerContext _context;

        public ArticleCategoryRepository(MasterBloggerContext context)
        {
            _context = context;
        }

        public List<ArticleCategory> GetAll()
        {
            var model = _context.ArticleCategory.ToList();
            return model;
        }

        public void Create(ArticleCategory entity)
        {
            _context.ArticleCategory.Add(entity);
            _context.SaveChanges();
        }
    }
}
